class Student {
  constructor(id, name, age, parents, phoneNumber, specialNeeds, status) {
    this.id = id;
    this.name = name;
    this.age = age;
    this.parents = parents;
    this.phoneNumber = phoneNumber;
    this.specialNeeds = specialNeeds;
    this.status = status;
  }
}

module.exports = Student;
