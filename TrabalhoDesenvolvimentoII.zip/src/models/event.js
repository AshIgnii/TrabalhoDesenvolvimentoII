class Event {
  constructor(id, description, comments, date) {
    this.id = id;
    this.description = description;
    this.comments = comments;
    this.date = date;
  }
}

module.exports = Event;
