class Teacher {
  constructor(id, name, schoolDiscipline, contact, phoneNumber, status) {
    this.id = id;
    this.name = name;
    this.schoolDiscipline = schoolDiscipline;
    this.contact = contact;
    this.phoneNumber = phoneNumber;
    this.status = status;
  }
}

module.exports = Teacher;
