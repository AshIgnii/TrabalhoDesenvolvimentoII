class User {
  constructor(id, name, email, user, pwd, level, status) {
    this.id = id;
    this.name = name;
    this.email = email;
    this.user = user;
    this.pwd = pwd;
    this.level = level;
    this.status = status;
  }
}

module.exports = User;
